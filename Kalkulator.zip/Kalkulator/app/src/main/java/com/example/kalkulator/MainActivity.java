package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Debug;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;


public class MainActivity extends AppCompatActivity {

    private Button btnKali, btnBagi, btnTambah,btnMin, btnSamaDengan, btnAngka1, btnAngka2,
                   btnAngka3, btnAngka4, btnAngka5, btnAngka6, btnAngka7, btnAngka8, btnAngka9,
                   btnAngka0, btnCE, btnC, btnBack, btnPlusMin, btnKoma;

    private mathParser stringEval = new mathParser(); // INI MANGGIL JAVA CLASS math parser nya //
    private String arr[] = new String[100]; // PENAMPUNG LIMIT DIGIT
    private String placeholder[] = new String[100]; // PENAMPUNG BUAT +/-
    private String operasi="";
    int i,j,k,jumlah_digit=0;
    private double hasil = 0;
    private boolean tambah = false ,kurang = false, bagi=false, kali=false , clickCount=false ,koma=false;
    private TextView tampilan,tampilanHistory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tampilan = findViewById(R.id.tampilan);
        tampilanHistory = findViewById(R.id.tampilanHistory);
        btnKali = findViewById(R.id.btnKali);
        btnBagi = findViewById(R.id.btnBagi);
        btnTambah = findViewById(R.id.btnTambah);
        btnMin = findViewById(R.id.btnMin);
        btnAngka0 = findViewById(R.id.angka0);
        btnAngka1 = findViewById(R.id.angka1);
        btnAngka2 = findViewById(R.id.angka2);
        btnAngka3 = findViewById(R.id.angka3);
        btnAngka4 = findViewById(R.id.angka4);
        btnAngka5 = findViewById(R.id.angka5);
        btnAngka6 = findViewById(R.id.angka6);
        btnAngka7 = findViewById(R.id.angka7);
        btnAngka8 = findViewById(R.id.angka8);
        btnAngka9 = findViewById(R.id.angka9);
        btnKoma = findViewById(R.id.btnKoma);
        btnPlusMin = findViewById(R.id.btnPlusMin);
        btnSamaDengan = findViewById(R.id.btnSamaDengan);
        btnCE = findViewById(R.id.btnCE);
        btnC = findViewById(R.id.btnC);
        btnBack = findViewById(R.id.btnBack);
        tampilan.setMovementMethod(new ScrollingMovementMethod());
        tampilanHistory.setMovementMethod(new ScrollingMovementMethod());

        // variabel j buat nge tresshold 15 digit //
        // variable i buat ngitung string semua nya //
        i=0;
        j=0;
        btnAngka1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(1);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(2);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(3);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(4);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(5);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(6);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(7);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(8);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits!",Toast.LENGTH_SHORT).show();
                }else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(9);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnAngka0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(j == 15){
                    Toast.makeText(getApplicationContext(),"Can't enter more than 15 digits.",Toast.LENGTH_SHORT).show();
                }else if(arr[i-1] == "/"){
                    Toast.makeText(getApplicationContext(),"Can't divide by zero.",Toast.LENGTH_SHORT).show();
                }
                else{
                    tambah = false; kurang =false; bagi=false; kali=false; clickCount = false;  koma=false;
                    arr[i] = String.valueOf(0);
                    tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                    i++;
                    j++;
                }
            }
        });

        btnKoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(koma == false && i > 0){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/")) {
                        arr[i] = "0.";
                        tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                        koma = true;
                        i++;
                    }else{
                        arr[i] = ".";
                        tampilanHistory.setText(tampilanHistory.getText() + arr[i]);
                        koma=true;
                    }
                }else if(koma == false && i ==0){
                    tampilanHistory.setText("0.");
                    arr[i] = "0.";
                    koma = true;
                    i++;
                }
                else{
                    tampilanHistory.setText(tampilanHistory.getText());
                }
            }
        });

        btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j=0;
                Arrays.fill(placeholder,null);
                // KONDISI KALO GADIISI APA2 TERUS KLIK '+' //
                if(i == 0 && tambah == false){
                    tampilanHistory.setText("");
                }
                // KONDISI KALO sebelumnya udah ada OPERATOR GABISA KLIK TAMBAH //
                else if(i > 0 && tambah == false){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "0.")) {
                        tampilanHistory.setText(tampilanHistory.getText());
                    }else{
                        tampilanHistory.setText(tampilanHistory.getText() + "+");
                        arr[i] = "+";
                        tambah =  true;
                        i++;
                    }
                }
                // KONDISI KALO sebelumnya udah klik tambah gabisa klik tambah //
                else if(i > 0 && tambah == true){
                    tampilanHistory.setText(tampilanHistory.getText());
                }
            }
        });

        btnMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j=0;
                Arrays.fill(placeholder,null);
                if(i == 0 && kurang == false){
                    tampilanHistory.setText("");
                }
                else if(i > 0 && kurang == false){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "0.")) {
                        tampilanHistory.setText(tampilanHistory.getText());
                    }else{
                        tampilanHistory.setText(tampilanHistory.getText() + "-");
                        arr[i] = "-";
                        kurang =  true;
                        i++;
                    }
                }
                else if(i > 0 && kurang == true){
                    tampilanHistory.setText(tampilanHistory.getText());
                }
            }
        });

        btnKali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j=0;
                Arrays.fill(placeholder,null);
                if(i == 0 && kali == false){
                    tampilanHistory.setText("");
                }
                else if(i > 0 && kali == false){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "0.")) {
                        tampilanHistory.setText(tampilanHistory.getText());
                    }else{
                        tampilanHistory.setText(tampilanHistory.getText() + "*");
                        arr[i] = "*";
                        kali =  true;
                        i++;
                    }
                }
                else if(i > 0 && kali == true){
                    tampilanHistory.setText(tampilanHistory.getText());
                }
            }
        });

        btnBagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j=0;
                Arrays.fill(placeholder,null);
                if(i == 0 && bagi == false){
                    tampilanHistory.setText("");
                }
                else if(i > 0 && bagi == false){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "0.")) {
                        tampilanHistory.setText(tampilanHistory.getText());
                    }
                    else{
                        tampilanHistory.setText(tampilanHistory.getText() + "/");
                        arr[i] = "/";
                        bagi =  true;
                        i++;
                    }
                }
                else if(i > 0 && bagi == true){
                    tampilanHistory.setText(tampilanHistory.getText());
                }
            }
        });

        btnSamaDengan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(i == 0 && (tambah == true || bagi == true || kali == true || kurang || true)){
                    tampilanHistory.setText("");
                }else if(i > 0 && (tambah == true || bagi == true || kali || true || kurang == true)){
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "0.")){
                        tampilanHistory.setText(tampilanHistory.getText());
                    }else{
                        i = 0;
                        while(arr[i] != null){
                            operasi += arr[i];
                            i++;
                        }
                        hasil = stringEval.eval(operasi);
                        tampilan.setText(String.valueOf(hasil));
                        hasil = 0;
                        operasi = "";
                        tambah = false; kurang =false; bagi=false; kali=false;
                    }
                }
            }
        });


        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tampilan.setText("");
                tampilanHistory.setText("");
                Arrays.fill(arr, null );
                Arrays.fill(placeholder, null );
                i = 0;
                hasil = 0;
                j = 0;
            }
        });

        btnCE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(i == 0){
                    tampilanHistory.setText("");
                    tampilan.setText("");
                }else{
                    tampilanHistory.setText("");
                    tampilan.setText("");
                    arr[i-1] = null;
                    i--;
                    for(j=0;arr[j] != null || arr[j] == "STOP" ;j++){
                        tampilanHistory.setText(tampilanHistory.getText() + arr[j]);
                    }
                }
            }
        });

        btnPlusMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(i == 0 ){
                    tampilanHistory.setText("");
                }else{
                    if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/")) {
                        tampilanHistory.setText(tampilanHistory.getText());
                    }else{
                        if(clickCount == true){
                            tampilanHistory.setText("");
                            for(;i>0; i--){
                                if((arr[i-1] == "+") || (arr[i-1] == "*") || (arr[i-1] == "/") || (arr[i-1] == "-" && arr[i-2] != "(") ) {
                                    break;
                                }else if( arr[i-1] == "-" && arr[i-2] == "("){
                                    arr[i-1] = null;
                                    arr[i-2] = null;
                                }
                                else{
                                    arr[i-1] = null;
                                }
                            }
                            k = jumlah_digit-1;
                            while(k+1>0){
                                arr[i] = placeholder[k];
                                i++;
                                k--;
                            }
                            clickCount = false;
                        }
                        else if (clickCount == false){
                            tampilanHistory.setText("");
                            jumlah_digit = 0;
                            for(;i>0; i--){
                                 if((arr[i-1] == "+") || (arr[i-1] == "-") || (arr[i-1] == "*") || (arr[i-1] == "/")){
                                     break;
                                 }else{
                                     placeholder[jumlah_digit] = arr[i-1];
                                     arr[i-1] = null;
                                     jumlah_digit++;
                                 }
                            }
                            arr[i] = "(";
                            arr[i+1] = "-";
                            i = i+2;
                            k = jumlah_digit-1;
                            while(k+1 > 0){
                                arr[i] = placeholder[k];
                                i++;
                                k--;
                            }
                            clickCount = true;
                        }
                        for(k=0; arr[k] != null ;k++){
                            tampilanHistory.setText(tampilanHistory.getText() + arr[k]);
                        }
                    }
                }
            }
        });
    }
}
