package com.example.week04_19633;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {
    private EditText fragment_first_edit_text;
    private Button fragment_first_btn_berubah;
    private TextView fragment_second_text_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        fragment_first_edit_text = findViewById(R.id.fragment_first_edit_text);
        fragment_first_btn_berubah =  findViewById(R.id.framgent_first_btn_berubah);
        fragment_second_text_view = findViewById(R.id.framgent_second_textview);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Fragment firstFragment = new FirstFragment();
        fragmentTransaction.replace(R.id.third_activity_fragment_1,firstFragment);

        Fragment secondFragment = new SecondFragment();
        fragmentTransaction.replace(R.id.third_activity_fragment_2,secondFragment);

        fragmentTransaction.commit();

    }
}
