package com.example.week04_19633;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnHalaman1, btnHalaman2;
    private EditText txtIsi, txtUrl;
    private Button btnKirim, btnBrowse;
    private TextView txtJawaban;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtIsi = findViewById(R.id.isi);
        txtUrl = findViewById(R.id.url);
        btnBrowse = findViewById(R.id.btnBrowse);
        btnKirim = findViewById(R.id.btnSubmit);
        txtJawaban = findViewById(R.id.jawaban);
        btnHalaman1 = findViewById(R.id.btnHal1);
        btnHalaman2 = findViewById(R.id.btnHal2);

        btnHalaman1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent halaman1 = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(halaman1);
            }
        });

        btnHalaman2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent halaman2 = new Intent(MainActivity.this, ThirdActivity.class);
                startActivity(halaman2);
            }
        });

        btnBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlText = txtUrl.getText().toString();
                if (urlText.isEmpty()) {
                    urlText = "https://www.umn.ac.id/";
                }
                Intent browseIntent = new Intent(Intent.ACTION_VIEW);
                browseIntent.setData(Uri.parse(urlText));
                if (browseIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(browseIntent);
                }
            }
        });

        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDua = new Intent(MainActivity.this,
                        ActivityDua.class);
                String isian = txtIsi.getText().toString();
                intentDua.putExtra("PesanDariMain", isian);
                startActivityForResult(intentDua, 1);
            }
        });

    }

    public void onActivityResult(int requestCode,
                                 int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String jawaban = data.getStringExtra("Jawaban");
                txtJawaban.setText(jawaban);
            }
        }
    }
}
