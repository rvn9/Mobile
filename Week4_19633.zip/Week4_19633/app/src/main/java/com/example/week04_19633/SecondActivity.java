package com.example.week04_19633;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private EditText fragment_first_edit_text;
    private Button fragment_first_btn_berubah;
    private TextView fragment_second_text_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        fragment_first_edit_text = findViewById(R.id.fragment_first_edit_text);
        fragment_first_btn_berubah =  findViewById(R.id.framgent_first_btn_berubah);
        fragment_second_text_view = findViewById(R.id.framgent_second_textview);

        fragment_first_btn_berubah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String isian = fragment_first_edit_text.getText().toString();
                fragment_second_text_view.setText(isian);
            }
        });
    }
}
